package com.example.listcity;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

import android.widget.Button;
import android.widget.EditText;



public class MainActivity extends AppCompatActivity {

    ListView cityList;
    ArrayAdapter<String> cityAdapter;
    ArrayList<String> dataList;
    Button btnAdd, btnDelete, btnConfirm;
    EditText etCity;

    String selectedCity = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        cityList = findViewById(R.id.city_list);
        btnAdd = findViewById(R.id.btn_add);
        btnDelete = findViewById(R.id.btn_delete);
        btnConfirm = findViewById(R.id.btn_confirm);
        etCity = findViewById(R.id.et_city);

        String[] cities = {"Edmonton", "Vancouver", "Moscow", "Sydney", "Berlin", "New Delhi", "Abbotabad", "Los Santos"};

        dataList = new ArrayList<>();
        dataList.addAll(Arrays.asList(cities));

        cityAdapter = new ArrayAdapter<>(this, R.layout.content, dataList);
        cityList.setAdapter(cityAdapter);
        cityList.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = dataList.get(position);
        });
        btnConfirm.setOnClickListener(v -> {
            String newCity = etCity.getText().toString().trim();
            if (newCity.isEmpty()) return;

            dataList.add(newCity);
            cityAdapter.notifyDataSetChanged();
            etCity.setText("");
        });

        btnDelete.setOnClickListener(v -> {
            if (selectedCity == null) return;

            dataList.remove(selectedCity);
            cityAdapter.notifyDataSetChanged();
            selectedCity = null;
        });

        btnAdd.setOnClickListener(v -> {
            // Minimal implementation: prepare input for user
            etCity.setText("");
            selectedCity = null;
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}